let topUpPlans = [
  {
    duration: "14 日",
    title: "14 日 14 GB",
    subtitle: "14 日 14 GB",
    price: 100,
    data: "14 GB",
    validity: "14 日",
    network: "使用中國聯通網絡",
	},
 {
    duration: "30 日",
    title: "30 日 20 GB",
    subtitle: "30 日 20 GB",
    price: 200,
    data: "20 GB",
    validity: "30 日",
    network: "使用中國聯通網絡",
	},
	 {
    duration: "365 日",
    title: "365 日 80 GB",
    subtitle: "365 日 80 GB",
    price: 600,
    data: "80 GB",
    validity: "365 日",
    network: "使用中國聯通網絡",
	},
	topUpPlans = [
  ...topUpPlans,
  /*...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans, */
];

let topUpPlanList = document.querySelector(".top-up--card-list");

let topUpCard = document.querySelector(".top-up--card");
topUpCard.remove();

for (let topUpPlan of topUpPlans) {
  topUpCard = topUpCard.cloneNode(true);
  let featureList = topUpCard.querySelector(".top-up--feature-list");
  featureList.textContent = "";
  function addPoint(text) {
    let li = document.createElement("li");
    li.textContent = text;
    featureList.appendChild(li);
  }
  topUpCard.querySelector(".top-up--plan-name").textContent = topUpPlan.title;
  topUpCard.querySelector(".top-up--price").textContent = "$" + topUpPlan.price;
  topUpCard.querySelector(".top-up--subtitle").textContent = topUpPlan.subtitle;
  topUpCard.querySelector(".top-up--quota").textContent = topUpPlan.max_speed
    ? `本地數據 (最高 ${topUpPlan.max_speed})`
    : `本地通話`;
  addPoint("有效期限：" + topUpPlan.validity);
  if (topUpPlan.data) {
    addPoint("本地數據：" + topUpPlan.data);
  }
  if (topUpPlan.call) {
    addPoint("本地話音：" + topUpPlan.call);
  }
  topUpPlanList.appendChild(topUpCard);
}

];
