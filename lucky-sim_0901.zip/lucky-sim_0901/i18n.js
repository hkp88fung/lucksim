let langs = {
  '社交媒體': 'Social Media',
  '銷售渠道': 'Sales Channel',
  '月費上台': 'Monthly Subscription',
  '預付卡': 'Prepaid Card',
  '擕號轉台': 'Number Porting',
  '常用USSD碼': 'Common USSD Codes',
  '條款及細則': 'Terms and Conditions',
  '私隱權政策': 'Privacy Policy',
  '數據服務充值': 'Data Service Recharge',
  '電話卡(話音)充值': 'Voice SIM Recharge',
  '查詢用量': 'Check Usage',
  '實名登記': 'Real Name Registration',
  '購買儲值卡': 'Purchase Prepaid Card',
  '購買儲值卡、數據卡 或 辦理攜號轉台 或 月費上台':
    'Purchase Prepaid/Data Card or Number Porting/Monthly Plan',
  '詳情請參閱我們的 Facebook 專頁': 'For details, please see our Facebook page',
  'Facebook 專頁': 'Facebook Page',
  '使用時間': 'Usage Time',
  '本地': 'Local',
  '中國': 'China',
  '英國': 'UK',
  '17國': '17 C',
  '購買': 'Purchase',
  '致電客戶服務': 'Call Customer Service',
  '星期一至五 09:30-18:00': 'Monday to Friday 09:30-18:00',
  '星期六 09:30-14:00': 'Saturday 09:30-14:00',
  '星期日及公眾假期休息': 'Closed on Sundays and Public Holidays',
}

let missingKeys = []
document.querySelectorAll('[i18n]').forEach(node => {
  let key = node.innerText
  node.dataset.lang = key
  if (key in langs) {
    return
  }
  missingKeys.push(key)
  console.warn('missing translation for:', key)
})
if (missingKeys.length > 0) {
  console.log('Prompt:')
  console.log(`
\`\`\`
let langs = {
  '社交媒體': 'Social Media',
  '電話卡(話音)充值': 'Voice SIM Recharge',
  '英國': 'UK',
  '17國': '17 C',
  '星期一至五 09:30-18:00': 'Monday to Friday 09:30-18:00',
  '星期六 09:30-14:00': 'Saturday 09:30-14:00',
}

\`\`\`

add ${missingKeys.map(s => JSON.stringify(s)).join(', ')}
`)
}

let lang
function setLang(value) {
  lang = value
  console.log({ lang })
  let nodes = document.querySelectorAll('[data-lang]')
  for (let node of nodes) {
    let key = node.dataset.lang
    let value = lang == 'zh-hk' ? key : langs[key]
    node.textContent = value
  }
  updatePlanList()
}
setLang('zh-hk')

function concat_words(a, b) {
  if (lang == 'en') {
    return a + ' ' + b
  }
  return a + b
}

function translate_words(text) {
  if (lang == 'en') {
    return text
      .replaceAll('年', 'Year')
      .replaceAll('日', 'Day')
      .replaceAll('分鐘通話', 'Min. Voice Call')
      .replaceAll('分鐘', 'Min.')
      .replaceAll('使用中國聯通網絡', 'Use China Unicom Network')
      .replaceAll('保留電話號碼', 'Preserve Phone Number')
  }
  return text
}
