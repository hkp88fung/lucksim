let topUpPlans = [
  {
    duration: '3 年',
    title: '3 年 250 GB',
    subtitle: '3 年 250 GB',
    price: 638,
    data: '250 GB',
    max_speed: '100 Mbps',
    validity: '1095 日',
    call: '10000 分鐘',
    region: '本地',
  },
  {
    duration: '3 年',
    title: '3 年 200 GB',
    subtitle: '3 年 200 GB',
    price: 600,
    data: '200 GB',
    max_speed: '100 Mbps',
    validity: '1095 日',
    call: '10000 分鐘',
    region: '本地',
  },
  {
    duration: '3 年',
    title: '3 年 150 GB',
    subtitle: '3 年 150 GB',
    price: 350,
    data: '150 GB',
    max_speed: '100 Mbps',
    validity: '1095 日',
    call: '5000 分鐘',
    region: '本地',
  },
  {
    duration: '3 年',
    title: '3 年 120 GB',
    subtitle: '3 年 120 GB',
    price: 328,
    data: '120 GB',
    max_speed: '100 Mbps',
    validity: '1095 日',
    call: '4000 分鐘',
    region: '本地',
  },
  {
    duration: '3 年',
    title: '3 年 保留電話號碼',
    subtitle: '3 年 8 GB',
    price: 138,
    data: '8 GB',
    max_speed: '21 Mbps',
    validity: '1095 日',
    call: '1000 分鐘',
    region: '本地',
  },
  {
    duration: '2 年',
    title: '2 年 90 GB',
    subtitle: '2 年 90 GB',
    price: 275,
    data: '90 GB',
    max_speed: '100 Mbps',
    validity: '730 日',
    call: '3000 分鐘',
    region: '本地',
  },
  {
    duration: '2 年',
    title: '2 年 80 GB',
    subtitle: '2 年 80 GB',
    price: 240,
    data: '80 GB',
    max_speed: '100 Mbps',
    validity: '730 日',
    call: '2000 分鐘',
    region: '本地',
  },
  {
    duration: '2 年',
    title: '2 年 70 GB',
    subtitle: '2 年 70 GB',
    price: 225,
    data: '70 GB',
    max_speed: '100 Mbps',
    validity: '730 日',
    call: '3000 分鐘',
    region: '本地',
  },
  {
    duration: '2 年',
    title: '2 年 60 GB',
    subtitle: '2 年 60 GB',
    price: 190,
    data: '60 GB',
    max_speed: '100 Mbps',
    validity: '730 日',
    call: '2000 分鐘',
    region: '本地',
  },
  {
    duration: '2 年',
    title: '2 年 50 GB',
    subtitle: '2 年 50 GB',
    price: 170,
    data: '50 GB',
    max_speed: '100 Mbps',
    validity: '730 日',
    call: '3000 分鐘',
    region: '本地',
  },
  {
    duration: '1.5 年',
    title: '1.5 年 40 GB',
    subtitle: '1.5 年 40 GB',
    price: 150,
    data: '40 GB',
    max_speed: '100 Mbps',
    validity: '540 日',
    call: '2000 分鐘',
    region: '本地',
  },
  {
    duration: '1.5 年',
    title: '1.5 年 30 GB',
    subtitle: '1.5 年 30 GB',
    price: 130,
    data: '30 GB',
    max_speed: '100 Mbps',
    validity: '540 日',
    call: '2000 分鐘',
    region: '本地',
  },
  {
    duration: '1 年',
    title: '1 年 20 GB',
    subtitle: '1 年 20 GB',
    price: 120,
    data: '20 GB',
    max_speed: '100 Mbps',
    validity: '365 日',
    call: '10000 分鐘',
    region: '本地',
  },
  {
    duration: '1 年',
    title: '1 年 10 GB',
    subtitle: '1 年 10 GB',
    price: 100,
    data: '10 GB',
    max_speed: '100 Mbps',
    validity: '365 日',
    call: '2000 分鐘',
    region: '本地',
  },
  {
    duration: '1 年',
    title: '1 年 5 GB',
    subtitle: '1 年 5 GB',
    price: 70,
    data: '5 GB',
    max_speed: '100 Mbps',
    validity: '365 日',
    call: '2000 分鐘',
    region: '本地',
  },

  {
    duration: '1 年',
    title: '1 年 1000 分鐘通話',
    subtitle: '1 年 1000 分鐘',
    price: 60,
    validity: '365 日',
    call: '1000 分鐘',
    region: '本地',
  },
  {
    duration: '1 年',
    title: '1 年 留言信箱',
    subtitle: '1 年 留言信箱',
    price: 60,
    validity: '365 日',
  },
  {
    duration: '180 日',
    title: '180 日 10 GB',
    subtitle: '180 日 10 GB',
    price: 90,
    data: '10 GB',
    max_speed: '100 Mbps',
    validity: '180 日',
    call: '1000 分鐘',
    region: '本地',
  },
  {
    duration: '120 日',
    title: '120 日 1 GB',
    subtitle: '120 日 1 GB',
    price: 35,
    data: '1 GB',
    max_speed: '100 Mbps',
    validity: '120 日',
    call: '500 分鐘',
    region: '本地',
  },
  {
    duration: '30 日',
    title: '30 日 10 GB',
    subtitle: '30 日 10 GB',
    price: 60,
    data: '10 GB',
    max_speed: '100 Mbps',
    validity: '30 日',
    call: '200 分鐘',
    region: '本地',
  },
  {
    duration: '365 日',
    title: '365 日',
    subtitle: '365 日 80 GB',
    price: 600,
    data: '80 GB',
    validity: '365 日',
    remark: '使用中國聯通網絡',
    region: '中國',
  },
  {
    duration: '30 日',
    title: '30 日',
    subtitle: '30 日 20 GB',
    price: 200,
    data: '20 GB',
    validity: '30 日',
    remark: '使用中國聯通網絡',
    region: '中國',
  },
  {
    duration: '14 日',
    title: '14 日',
    subtitle: '14 日 14 GB',
    price: 100,
    data: '14 GB',
    validity: '14 日',
    remark: '使用中國聯通網絡',
    region: '中國',
  },
]
topUpPlans = [
  ...topUpPlans,
  /*...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans,
  ...topUpPlans, */
]

let topUpPlanList = document.querySelector('.top-up--card-list')
let topUpRegionDiv = document.querySelector('.top-up--region')

let topUpCard = document.querySelector('.top-up--card')
topUpCard.remove()

function selectRegion(button) {
  let buttons = document.querySelectorAll('#sideBar button')
  for (let button of buttons) {
    button.classList.remove('selected')
  }
  button.classList.add('selected')
  document.querySelector('.top-up--region')
  topUpRegionDiv.textContent = button.innerText
  updatePlanList()
}

function updatePlanList() {
  let region = document.querySelector('#sideBar button.selected [data-lang]')
    .dataset.lang

  let matchedPlans = topUpPlans.filter(plan => plan.region == region)

  let durations = Array.from(new Set(matchedPlans.map(plan => plan.duration)))
    .map(text => {
      let parts = text.split(' ')
      let value = +parts[0]
      let unit = parts[1]
      if (unit == '年') {
        value *= 365
      }
      return { text, value }
    })
    .sort((a, b) => b.value - a.value)
    .map(duration => duration.text)

  let duration = durations.includes(duration_select.value)
    ? duration_select.value
    : durations[0]

  duration_select.textContent = ''
  for (let duration of durations) {
    let option = document.createElement('option')
    option.value = duration
    option.textContent = translate_words(duration)
    duration_select.appendChild(option)
  }
  duration_select.value = duration

  topUpPlanList.textContent = ''
  for (let topUpPlan of matchedPlans) {
    if (topUpPlan.duration != duration) {
      continue
    }
    topUpCard = topUpCard.cloneNode(true)
    let featureList = topUpCard.querySelector('.top-up--feature-list')
    featureList.textContent = ''
    function addPoint(text) {
      let li = document.createElement('li')
      li.textContent = text
      featureList.appendChild(li)
    }
    topUpCard.querySelector('.top-up--plan-name').textContent = translate_words(
      topUpPlan.title,
    )
    topUpCard.querySelector('.top-up--price').textContent =
      '$' + topUpPlan.price
    topUpCard.querySelector('.top-up--subtitle').textContent = translate_words(
      topUpPlan.subtitle,
    )
    topUpCard.querySelector('.top-up--quota').textContent = topUpPlan.max_speed
      ? lang == 'en'
        ? `Local Data (Max speed: ${topUpPlan.max_speed})`
        : `本地數據 (最高 ${topUpPlan.max_speed})`
      : topUpPlan.region == '本地'
      ? lang == 'en'
        ? 'Local Calls'
        : `本地通話`
      : ''
    addPoint(
      (lang == 'en' ? 'Validity Period: ' : '有效期限：') +
        translate_words(topUpPlan.validity),
    )
    if (topUpPlan.data) {
      addPoint(
        concat_words(
          topUpRegionDiv.textContent,
          lang == 'en' ? 'Data: ' : '數據：',
        ) + topUpPlan.data,
      )
    }
    if (topUpPlan.call) {
      addPoint(
        concat_words(
          topUpRegionDiv.textContent,
          lang == 'en' ? 'Voice: ' : '話音：',
        ) + translate_words(topUpPlan.call),
      )
    }
    if (topUpPlan.remark) {
      addPoint(translate_words(topUpPlan.remark))
    }
    topUpPlanList.appendChild(topUpCard)
  }
}

updatePlanList()
